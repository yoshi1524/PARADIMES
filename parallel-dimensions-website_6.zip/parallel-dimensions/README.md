# Parallel Dimensions — Website

Next.js 14 (App Router) + TypeScript + Tailwind CSS site for **Parallel Dimensions
Ads Corporation** — a Metro Manila bar-party and events promotions company.

Monochrome design system only: black, off-white, and silver. See
`tailwind.config.ts` for the exact token values (`void`, `iron`, `static`, `ash`,
`silver`, `bone`) and `app/globals.css` for the "rift" signature text effect
(the doubled/offset headline treatment used throughout, echoing the brand name).

## Getting started

```bash
npm install
cp .env.example .env.local   # optional — everything works with this empty
npm run dev                  # http://localhost:3000
```

> **Note on fonts:** this project loads Anton, Space Grotesk, and JetBrains Mono
> via `next/font/google`, which fetches them at build time. That requires normal
> internet access — it will work on your machine and on Vercel/Netlify, but will
> fail in network-locked sandboxes (like the one this project was scaffolded in).
> If you ever need fully offline builds, swap `next/font/google` for local font
> files with `next/font/local`.

## What's built vs. what's a placeholder

| Area | Status |
|---|---|
| Pages: Home, Events (list + detail), Testimonials, About, Partners, Contact | ✅ Built |
| Event status filter (past / present / upcoming) | ✅ Built |
| Ticket tiers & pricing for the sample events | ✅ Sourced from your guestlist workbook |
| Org chart / company blurb / services | ✅ Sourced from your capstone deck |
| Contact form + Feedback form | ✅ Built, but **no email/DB wired up** — see below |
| Chatbot widget (UI + API route) | ✅ Built, works with **zero config** via a rule-based responder |
| HelixPay ticket checkout | ⚠️ Placeholder — see `lib/helixpay.ts` |
| GCash payment | ⚠️ Placeholder — see `lib/gcash.ts` |
| Real event photography / venue names | ⚠️ Placeholder — replace in `lib/data/events.ts` |

Nothing is faked to look more finished than it is: every placeholder integration
is a real, working code path with a mock response, clearly commented, so the
site is demoable end-to-end today and becomes "real" by filling in one env var
and one `fetch()` call at a time.

## Internal management system (role-based dashboards)

Your capstone's Chapter 3 describes a full internal system with role-based
dashboards — not just the public marketing/ticketing site. That's now built
in here too, at `/admin` (staff) and `/portal` (clients), gated by a login
at `/login`.

**⚠️ Tech-stack deviation, on purpose:** Chapter 3 specifies Laravel 11 +
PHP + MySQL + Bootstrap. This is built in Next.js/React/Tailwind instead,
per your call — it's faster to iterate on and this repo is already in that
stack. Flag this explicitly in your defense as a documented deviation from
the proposal, with the reasoning (faster iteration, single codebase for
public site + internal system, still delivers every role/feature Chapter 3
specifies).

### Roles implemented (from Table 3 / the Use Case Diagram)

| Role | Where | What they see |
|---|---|---|
| System Administrator | `/admin/users` + everything | User accounts, full access |
| Administrative (CEO/Management) | everything | Same as System Admin |
| Manager | `/admin`, `/admin/promotions`, `/admin/events`, `/admin/inquiries` | Task/commission oversight |
| Admin | `/admin`, `/admin/events`, `/admin/inquiries`, `/admin/services`, `/admin/org-chart` | Event & payment management |
| Marketing Department | `/admin`, `/admin/marketing`, `/admin/testimonials`, `/admin/services`, `/admin/newsletter`, `/admin/org-chart` | Campaigns, content, leads |
| Promotions Department | `/admin`, `/admin/promotions`, `/admin/testimonials` | Promoter/referral/commission data |
| Promoter | `/admin`, `/admin/promotions` (own referrals only) | Their own commission activity |
| Client | `/portal` | Submit/track business inquiries |

### Demo login

No real accounts or database exist yet — see `lib/auth.ts` for the demo
directory. Sign in at `/login` with any of these emails and the fixed demo
code `123456`:

```
sysadmin@paralleldimensions.ph      System Administrator
ceo@paralleldimensions.ph           Administrative (CEO/Management)
manager@paralleldimensions.ph       Manager
admin@paralleldimensions.ph         Admin
marketing@paralleldimensions.ph     Marketing Department
promotions@paralleldimensions.ph    Promotions Department
promoter@paralleldimensions.ph      Promoter (try this one — Nate Villegas
                                     has real commission rows from the
                                     guestlist workbook)
client@paralleldimensions.ph        Client
```

### Testimonial moderation (Marketing / Promotions / System Admin / Administrative)

`/admin/testimonials` now has real filter + approve/disapprove controls, not
just a static list:
- Filter by status (All / Pending / Published / Rejected), star rating, or
  search by name/quote text.
- **Approve** publishes it immediately — it shows up on the public
  `/testimonials` page and homepage right away (see
  `getPublishedTestimonials()` in `lib/data/staff.ts`, which merges the
  seed testimonials with anything approved).
- **Disapprove** takes an optional reason, keeps it off the public site,
  and records who rejected it and when.
- API: `POST /api/admin/testimonials/[id]` with `{ action: "approve" | "reject" }`.

### Posting new events (Marketing, plus Admin/Manager)

`/admin/marketing/events/new` is a form covering the fields standard event
platforms (Eventbrite, Hi.Events) and event-planning checklists treat as
essential — beyond the basics (title/date/venue), it covers **host/organizer,
DJ/performer lineup, event partners/sponsors, dress code, and age
requirement** — plus ticket tiers. Submitting it calls
`POST /api/admin/events`, which pushes straight into the same in-memory
`events` array everything else reads from (see `addEvent()` in
`lib/data/events.ts`) — so a new listing appears on the public Events page
immediately, no redeploy needed.

Access: Marketing, Admin, and Manager can all reach this form (Admin/Manager
via the same URL, since Chapter 3 has them managing events operationally
too) — adjust `ALLOWED_ROLES` in `app/api/admin/events/route.ts` and the nav
filters in `lib/auth.ts` if you want to narrow that.

### What's real vs. mocked in here

- **Real, working end-to-end:** login flow, session cookie, route
  protection (`middleware.ts`), role-based nav (`lib/auth.ts`), the client
  inquiry portal (submit → shows up in Admin's inquiry queue → staff can
  reply → client sees the reply), the testimonial moderation queue
  (submit → pending in `/admin/testimonials` → approve/reject → reflects
  publicly), and posting new events (form → appears on the public site).
- **Mocked, clearly marked in code:** marketing campaign metrics, the
  payment verification queue on `/admin/events`, and the newsletter
  subscriber list. Promoter/commission figures on `/admin/promotions` are
  **not** mocked — they're pulled from your actual LOVE SICK 2026 guestlist
  workbook (a representative sample of it).
- **Storage:** inquiries, pending feedback, and any events posted through
  the form live in plain in-memory arrays (`lib/data/staff.ts`,
  `lib/data/events.ts`) so the whole flow is demoable without a database.
  This resets whenever the dev server restarts and will **not** work
  correctly on a serverless deployment (Vercel functions don't share memory
  between invocations) — swap for a real database before relying on it
  past a local demo.
- **Auth security:** the session cookie is unsigned base64 (see the
  warning comment in `lib/session.ts`) and OTP is a fixed demo code, not a
  real emailed one-time code. Both are fine for a defense demo, not for
  anything with real user data.

## Wiring up the real integrations

### 1. HelixPay (ticketing)
`lib/helixpay.ts` now calls HelixPay's real endpoints, verified against
their public docs (helixpay.readme.io) as of July 2026:

- Base URL defaults to the sandbox host their **endpoint reference** shows
  (`https://api-sandbox.helixpay.ph`) — note their prose "Getting Started"
  page names a *different* sandbox host (`api-sandbox.helixsandbox.com`).
  The two didn't match when I checked. **Confirm which is current for your
  account** by downloading the Postman collection from your Merchant
  Console (Credentials page) before going live — don't trust either blindly.
- `POST /v1/checkouts` is documented and wired up.
- The token endpoint (how you exchange Client ID/Secret for a Bearer token)
  isn't published on the pages readable without logging in. `getHelixPayToken()`
  in `lib/helixpay.ts` has a `TODO` with a best-guess path — get the real one
  from your Postman collection and fix it there.
- The exact body fields for `POST /v1/checkouts` also render dynamically
  behind login and weren't fully extractable. What's in the code now is a
  best-effort shape based on fields HelixPay's own **webhook payloads**
  confirm exist (`reference_id`, `payor`, `success_redirect_url`,
  `failure_redirect_url`, a `products[]` array). Cross-check this against
  the Postman collection and adjust field names as needed.
- HelixPay is a *subscription* platform at its core — a single event
  ticket has to be modeled as a Product/Product Variant you set up in the
  Merchant Console first. That product's ID goes into `helixpayEventId` in
  `lib/data/events.ts`.
- A webhook receiver is already built at `app/api/webhooks/helixpay/route.ts`
  (handles `payment.success`, `payment.failed`, `subscription.created` —
  the event types HelixPay documents). Register your deployed URL
  (`https://yourdomain.com/api/webhooks/helixpay`) in the Merchant Console.
  **It doesn't verify a signature yet** — confirm HelixPay's signing scheme
  for your account and add that check before trusting the payload in
  production.

Until `HELIXPAY_CLIENT_ID` is set in `.env.local`, checkout falls back to
the mock flow at `/checkout/mock` so the site still demos end-to-end.

### 2. GCash
GCash doesn't offer a direct public merchant API — you'll reach it either
through HelixPay's own GCash support (check with them first, since your
ticketing may already cover it) or through a payment aggregator (PayMongo,
Xendit, Maya Business, etc.) that has a documented GCash e-wallet source.
`lib/gcash.ts` is structured the same way as the HelixPay stub — set
`GCASH_AGGREGATOR_API_KEY` and fill in the real call once you've picked one.

### 3. Chatbot
`app/api/chatbot/route.ts` already answers questions about events, pricing,
and partnerships using a rule-based responder — no setup required. If you set
`ANTHROPIC_API_KEY`, it upgrades automatically to a Claude-powered assistant
that answers from the same live event/service data (see `buildContext()` in
that file). Swap in a different LLM provider by replacing the `claudeReply()`
function.

### 5. Email notifications (Gmail)
`lib/mail.ts` sends real email via Gmail SMTP (using Nodemailer) once you
configure it — until then it logs to the console instead, so nothing
breaks while you're setting it up.

**Setup:**
1. On the Gmail account you want to send from, turn on 2-Step Verification:
   https://myaccount.google.com/security
2. Generate an App Password (choose "Mail" as the app type):
   https://myaccount.google.com/apppasswords — Google gives you a
   16-character code. Regular Gmail passwords won't work here; Google
   blocks that for third-party apps.
3. In `.env.local`, set `GMAIL_USER` (the sending address) and
   `GMAIL_APP_PASSWORD` (the 16-character code).

**What's wired to it:**
- **Contact form** (`/contact`) — routes to a different inbox depending on
  the reason picked (Venue/Business Partnership, Event Inquiry, Ticketing
  Support, Press/Media, Other), each configurable independently in
  `.env.local` via `CONTACT_EMAIL_*` (see `lib/contactRouting.ts`). If
  you only have one team inbox for now, just set `CONTACT_EMAIL_GENERAL` —
  everything falls back to it. The submitter also gets an automatic
  confirmation reply.
- **Testimonial submissions** (`/testimonials`) — notifies
  `CONTACT_EMAIL_MARKETING` when a new one comes in for review at
  `/admin/testimonials`.
- **Client portal inquiries** (`/portal`) — notifies
  `CONTACT_EMAIL_PARTNERSHIPS` when a client submits a new inquiry, and
  the client gets a confirmation. When either side (staff in `/admin` or
  the client in `/portal`) adds a reply, the other side gets emailed too —
  so the conversation doesn't only live inside the dashboard.

**One real limitation to know about:** Gmail's own sending limits apply
(roughly 500/day on a regular Gmail account) — fine for a capstone demo
and small real usage, not something to build a high-volume system on
without moving to a dedicated provider (Resend, SendGrid, Postmark) later.



## Content to replace before launch

- `lib/data/events.ts` — sample events (`LOVE SICK`, `Summer Paradimes`,
  `Manila Mi Vida`) with venue names marked `TBD Venue Partner` and ticket
  pricing pulled from your February 2026 guestlist workbook. Swap in real
  venues, dates, and confirmed pricing per event.
- `lib/data/testimonials.ts` — sample quotes marked as such in a code
  comment. Replace with real, permissioned guest/partner feedback (the
  feedback form on `/testimonials` is a good source once it's wired to
  storage).
- `lib/data/testimonials.ts` (`partners` export) — placeholder partner list;
  replace with your actual venue and platform partners.
- Cover art: event cards currently use monochrome gradient placeholders
  (`components/EventCard.tsx`) instead of photography, to keep the repo
  dependency-free. Swap in real event photos via `next/image` when ready.

## Project structure

```
app/
  layout.tsx            Root layout: fonts, header, footer, chatbot widget
  page.tsx               Home
  events/page.tsx         Events list with status filter
  events/[slug]/page.tsx   Event detail + ticket widget
  testimonials/page.tsx    Testimonials + feedback form
  about/page.tsx           Company info, org chart, services
  partners/page.tsx        Venue & platform partners
  contact/page.tsx         Contact form
  checkout/{mock,success,failed}/page.tsx   Post-checkout states
  api/checkout/route.ts    HelixPay checkout (mocked)
  api/gcash/route.ts       GCash charge (mocked)
  api/chatbot/route.ts     Chatbot (rule-based, upgrades to Claude if keyed)
  api/contact/route.ts     Contact form handler (logs only)
  api/feedback/route.ts    Feedback form handler (logs only)
components/               Header, Footer, Hero, EventCard, TicketWidget,
                           TestimonialCard, ContactForm, FeedbackForm, Chatbot
lib/data/                 events.ts, team.ts, testimonials.ts — all editable
lib/helixpay.ts           HelixPay integration point
lib/gcash.ts               GCash integration point
```
