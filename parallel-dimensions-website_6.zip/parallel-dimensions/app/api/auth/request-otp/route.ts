import { NextRequest, NextResponse } from "next/server";
import { DEMO_USERS } from "@/lib/auth";

/**
 * Step 1 of the demo login flow: look up the email, "send" an OTP.
 * No real SMTP is wired up (see .env.example / README) — the OTP is
 * always the fixed demo code, and this just confirms the email is a
 * known demo account so the UI can move to the OTP step.
 */
export async function POST(req: NextRequest) {
  const { email } = await req.json();
  const user = DEMO_USERS.find((u) => u.email.toLowerCase() === String(email).toLowerCase());

  if (!user) {
    return NextResponse.json({ error: "No account found for that email." }, { status: 404 });
  }

  console.log(`[auth:otp] Demo OTP for ${user.email} is 123456 (no real SMTP configured yet).`);
  return NextResponse.json({ ok: true, name: user.name, role: user.role });
}
